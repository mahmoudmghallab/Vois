package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {

	WebDriver driver;
	WebDriverWait wait;
	Actions action;
	// locators

	By signButton = By.className("login");
	By WomenBox= By.className("sf-with-ul");
	By blouses= By.xpath("//a[@href='http://automationpractice.com/index.php?id_category=7&controller=category']");

	public HomePage(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait (this.driver,30);
		action = new Actions(driver);
	}

	public LoginPage navigateToLoginPage() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signButton)).click();

		return new LoginPage(driver);

	}

}





