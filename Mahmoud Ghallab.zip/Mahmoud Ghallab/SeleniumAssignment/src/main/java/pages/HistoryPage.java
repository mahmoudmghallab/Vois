package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HistoryPage {
	WebDriver driver;
	WebDriverWait wait;
	
	By orderRefrenceTxt= By.className("color-myaccount");

	public HistoryPage(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait (this.driver,30);
	}
	
	public String getOrderRefrence() {
		
		return wait.until(ExpectedConditions.visibilityOfElementLocated(orderRefrenceTxt)).getText();
		
	}

}
