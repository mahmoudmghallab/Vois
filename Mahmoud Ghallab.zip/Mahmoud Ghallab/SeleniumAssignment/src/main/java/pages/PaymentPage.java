package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PaymentPage {

	WebDriver driver;
	WebDriverWait wait;

	By blouseTxt= By.className("cat-name");

	By addToCartBtn= By.xpath("//a[@href='http://automationpractice.com/index.php?id_product=2&controller=product']");
	By addToCartBtn2= By.id("add_to_cart");
	By proccedToCheckoutBtn1= By.xpath("//a[@href='http://automationpractice.com/index.php?controller=order']");
	By proccedToCheckoutBtn2= By.xpath("//a[@href='http://automationpractice.com/index.php?controller=order&step=1']");
	By proccedToCheckoutBtn3= By.name("processAddress");
	By checkBox = By.id("uniform-cgv");
	By proccedToCheckoutBtn4= By.name("processCarrier");
	By bankWireOption= By.className("bankwire");

	By confrim=By.xpath("(//button[@type='submit'])[2]");
	By confirmationMsg = By.className("cheque-indent");

	By backToOrderBtn= By.xpath("//a[@href='http://automationpractice.com/index.php?controller=history']");
	By confirmationDetails= By.className("box");



	public PaymentPage(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait (this.driver,30);
	}

	public String getTittle() {

		return driver.getTitle();
		//return	wait.until(ExpectedConditions.visibilityOfElementLocated(blouseTxt)).getText();

	}

	public String confirmOrder() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartBtn)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartBtn2)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(proccedToCheckoutBtn1)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(proccedToCheckoutBtn2)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(proccedToCheckoutBtn3)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(checkBox)).click();
		driver.findElement(proccedToCheckoutBtn4).click();
		// chose bank wire option
		driver.findElement(bankWireOption).click();
		// confirm the order

		driver.findElement(confrim).click();
		//return driver.findElement(confirmationMsg).getText();
		return wait.until(ExpectedConditions.visibilityOfElementLocated( confirmationDetails)).getText();


	}

	public HistoryPage navigateToHistorPage() {


		wait.until(ExpectedConditions.visibilityOfElementLocated(backToOrderBtn)).click();

		return new HistoryPage(driver);

	}
}
