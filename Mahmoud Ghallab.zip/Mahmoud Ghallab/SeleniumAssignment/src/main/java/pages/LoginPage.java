package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

	WebDriver driver;
	WebDriverWait wait;
	Actions action;

	//locators
	By userNameBox = By.id("email");
	By passwordBox = By.id("passwd");
	By signInBtn= By.id("SubmitLogin");
	By nameTxt= By.className("account");
	By WomenBox= By.className("sf-with-ul");
	By blouses= By.xpath("//a[@href='http://automationpractice.com/index.php?id_category=7&controller=category']");


	public LoginPage(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait (this.driver,30);
		action = new Actions(driver);
	}
	public PaymentPage login(String username,String password) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(userNameBox)).sendKeys(username);
		wait.until(ExpectedConditions.visibilityOfElementLocated(passwordBox)).sendKeys(password);
		driver.findElement(signInBtn).click();

		//Hover on women

		wait.until(ExpectedConditions.visibilityOfElementLocated(WomenBox));

		action.moveToElement(driver.findElement(WomenBox)).build().perform();
		// click on blouses
		wait.until(ExpectedConditions.visibilityOfElementLocated(blouses)).click();



		return new PaymentPage(driver);


	}
}