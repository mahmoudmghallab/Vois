package tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import pages.HistoryPage;
import pages.PaymentPage;






public class TestCases extends TestBase {
	
	String name;
	String tittleName;
	String message;
	String paymentDetails;
	String orderRefrence;
	HistoryPage historyPageObj;

	// login successfully & and chose blouse 
	@Test(priority = 1)
	public void setproduct() {

		loginPageObj = homePageObj.navigateToLoginPage();
		paymentPageObj = loginPageObj.login("mahmoudmghallab@gmail.com", "magdy");
		tittleName=paymentPageObj.getTittle();
		assertEquals("Blouses - My Store", tittleName);


	}


	//check order was replaced in history successfully 
	@Test(priority = 2)

	public void confirmTheOrder() {

		paymentDetails=paymentPageObj.confirmOrder();
		historyPageObj=paymentPageObj.navigateToHistorPage();
		orderRefrence=historyPageObj.getOrderRefrence();
		assertTrue(paymentDetails.contains(orderRefrence));


	}

}
