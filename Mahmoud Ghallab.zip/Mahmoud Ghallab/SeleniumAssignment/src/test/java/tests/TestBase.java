package tests;



import org.openqa.selenium.Dimension;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;


import io.github.bonigarcia.wdm.WebDriverManager;
import pages.HomePage;
import pages.LoginPage;
import pages.PaymentPage;


public class TestBase {
	public static ChromeDriver driver;
	public LoginPage loginPageObj;
	public HomePage homePageObj;
	public PaymentPage paymentPageObj;



	@BeforeClass
	public void openURL() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.navigate().to("http://automationpractice.com/index.php");

		driver.manage ().window ().setSize (new Dimension (1024, 768));

		homePageObj = new HomePage(driver);




	}
}
